from kafka import KafkaConsumer

consumer = KafkaConsumer(
    'variance',
    bootstrap_servers=['localhost:9093'],
     auto_offset_reset='earliest',
     enable_auto_commit=True,
     group_id='my-group',
     value_deserializer=lambda x: x.decode('utf-8'))

for message in consumer:
    message = message.value
    print("message:", message)

